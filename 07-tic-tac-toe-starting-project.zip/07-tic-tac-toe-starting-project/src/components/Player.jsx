import { useState } from "react";

export default function Player({ initialName, symbol, isActive }) {
  const [playerName, setPlayerName] = useState(initialName);
  const [isEditing, setEditing] = useState(false);

  function editName() {
    setEditing((isEditing) => !isEditing);
  }

  function saveChange(event) {
    const newName = event.target.value;
    setPlayerName(newName);
  }

  let content = <span className="player-name">{playerName}</span>;
  if (isEditing)
    content = (
      <input
        id="name"
        type="text"
        required
        placeholder={playerName}
        onChange={saveChange}
      />
    );

  return (
    <li className={isActive ? "active" : undefined}>
      <span className="player">
        {content}
        <span className="player-symbol">{symbol}</span>
      </span>
      <button onClick={() => editName()}>{isEditing ? "Save" : "Edit"}</button>
    </li>
  );
}
