import { useState } from "react";
import TapButton from './TapButton.jsx'
import { EXAMPLES } from "../data.js";
import Section from "./Section.jsx";

export default function Examples() {
  const [selectedTopic, setSelectedTopic] = useState();

  function handleSelect(selectedButton) {
    // components/jsx/props/states
    setSelectedTopic(selectedButton);
  }

  let tabContent = <p>No selected button</p>;
  if (selectedTopic)
    tabContent = (
      <div id="tab-content">
        <h3>{EXAMPLES[selectedTopic].title}</h3>
        <p>{EXAMPLES[selectedTopic].description}</p>
        <pre>
          <code>{EXAMPLES[selectedTopic].code}</code>
        </pre>
      </div>
    );

    const content=(
        <>    
          <menu>
            <TapButton
              onClick={() => handleSelect("Components")}
              isSelected={selectedTopic === "Components"}
            >
              Components
            </TapButton>
    
            <TapButton
              onClick={() => handleSelect("JSX")}
              isSelected={selectedTopic === "JSX"}
            >
              JSX
            </TapButton>
    
            <TapButton
              onClick={() => handleSelect("Props")}
              isSelected={selectedTopic === "Props"}
            >
              Props
            </TapButton>
    
            <TapButton
              onClick={() => handleSelect("States")}
              isSelected={selectedTopic === "States"}
            >
              States
            </TapButton>
          </menu>
          {tabContent}
        </>
    );

  return (<Section id="examples" title="Examples" content={content}></Section>);
}
