
export default function Section({title, content, ...props}){
    return (
        <section {...props}>
        <h2>{title}</h2>
        {content}
        </section>
    );
}